# Minha Trajetória — Elisângela de Souza

> Documento em formato narrativo, para a base de conhecimento do PortfolioAI. Cada seção corresponde a um período da minha trajetória profissional, escrito em primeira pessoa e em prosa, para servir de base a respostas conversacionais mais naturais. Todas as informações aqui são fiéis ao meu currículo oficial — nada foi inventado ou dramatizado além do que realmente aconteceu.

---

## Os primeiros passos (1999 – 2002)

Minha trajetória profissional começou em junho de 1999, na E.L.H Utilidades, em Barra Mansa. Comecei como auxiliar de serviços gerais, responsável pela limpeza e pelo recebimento de mercadorias. Com o tempo, passei a atuar também como operadora de caixa, função que exerci de dezembro de 2000 até janeiro de 2002. Foi ali que aprendi as primeiras rotinas de um ambiente de trabalho formal, disciplina e atendimento ao público.

---

## Instrução e primeiras equipes (2002 – 2007)

Entre janeiro e junho de 2003, passei por duas experiências que me aproximaram do universo da tecnologia e da formação de pessoas. Na R. Carvalho Lopes, em Volta Redonda, atuei como auxiliar de manutenção e também como instrutora de sistemas operacionais Microsoft, Office e internet. Logo depois, entre maio e agosto de 2003, fui auxiliar técnica na Fast Net, também em Volta Redonda, onde geri uma equipe de técnicos de laboratório e cuidei da agenda de atendimento em campo, além do atendimento a clientes de contrato via help desk.

Ainda em 2003, na GM Informática, assumi o cargo de Gerente de Treinamento, elaborando material didático e liderando uma equipe de dez colaboradores — minha primeira experiência de gestão de um time desse porte.

Entre abril de 2006 e abril de 2007, atuei na Ong Semente do Amanhã, em Barra Mansa, como Instrutora de Informática e Coordenadora. Dava aulas de Internet, Office e Windows, selecionava e treinava novos colaboradores e produzia material didático — um período que consolidou meu gosto por ensinar e por estruturar processos de capacitação.

---

## Consolidação técnica em TI (2007 – 2012)

De abril de 2007 a novembro de 2008, trabalhei na Elca Tecnologia e Informática, em Barra Mansa, onde passei por diferentes responsabilidades: Técnica de Informática, Técnica de Bancada e, depois, Gerente de Laboratório. Nessa fase, geri uma equipe de técnicos, fiz reparo em computadores, dei suporte via Help Desk, atendi pessoas físicas e jurídicas, controlei estoque e treinei novos funcionários — uma experiência completa que uniu conhecimento técnico e gestão de equipe.

Na sequência, entre novembro de 2008 e setembro de 2009, atuei na Info in Time Informática, em Volta Redonda, como Técnica de Informática e Técnica de Bancada, com foco em reparo e instalação de placas em microcomputadores e notebooks, além de montagem e instalação de sistemas operacionais e programas.

Depois, entre janeiro e abril de 2010, fui estagiária na empresa de Nilton Machado de Ávila, em Barra Mansa, supervisionando e coordenando equipe, cotando preços, comprando materiais e participando de processos seletivos e tomadas de decisão.

Ainda em 2010, de outubro a janeiro de 2011, vivi uma experiência diferente na Barrama Celulares, em Barra Mansa, atuando como Consultora em vendas externas de planos pós-pagos para clientes business, com foco em prospecção de clientes.

Entre maio de 2011 e abril de 2012, retornei à área técnica na Centercell Telefonia, em Barra Mansa, como Técnica de Informática, configurando, mantendo e administrando redes de comunicação, dando suporte a unidades administrativas na implementação de soluções, atuando em help desk e monitorando ambientes para diagnosticar situações que comprometessem disponibilidade, performance e funcionalidade.

---

## A porta de entrada para a indústria (2012 – 2013)

Em maio de 2012, comecei a trabalhar na Asyst International + Rhealeza, atuando no Projeto Sigma, como Auxiliar Administrativo I, até março de 2013. Foi um período intenso de rotina administrativa dentro de um ambiente industrial: digitava correções de documentos de identificação de riscos em espaços confinados (Irepecs) e os inseria na intranet, elaborava apresentações mensais para o comitê tático de segurança da gerência geral, preparava apresentações quadrimestrais do comitê de gestão ambiental e da qualidade, e organizava as reuniões mensais de prevenção de acidentes (Rempa).

Também ficava responsável por preparar apresentações de auditorias internas e externas de qualidade e meio ambiente, atualizar e controlar as pastas de falhas e interferências (Fraf's) do sistema ambiental e de qualidade, controlar o comparecimento dos funcionários da gerência em exames periódicos e treinamentos, elaborar documentos relacionados a segurança, meio ambiente e qualidade, e fazer consultas e extrair informações e gráficos do Sistema Ambiental (SIA). Foi esse contato próximo com os processos internos da indústria que me aproximou definitivamente da CSN.

Entre março e maio de 2013, ainda pela Asyst International + Rhealeza, mas agora no Projeto CSN/Campo UPV, atuei como Técnico de Suporte Júnior, prestando suporte local a hardware e software, atendendo chamados de emergência presencialmente, via help desk e remotamente, além de configurar hardwares, redes e instalar programas e sistemas operacionais.

---

## Mais de uma década na CSN (2013 – atualidade)

Em junho de 2013, ingressei na CSN, na Usina Presidente Vargas, em Volta Redonda, como Operadora de Produção II — cargo que ocupo até hoje, já há mais de uma década. É a experiência mais longa e mais consolidada da minha trajetória.

No dia a dia, faço gestão interina de equipe, elaboro projetos de melhoria e padrões operacionais, e controlo documentação em atendimento aos Sistemas de Gestão da Qualidade (SGQ) e Ambiental (SGA). Opero sistemas de captação e recirculação de água crua, sistemas de distribuição de água clarificada e tratada, e sistemas de desidratação de lama. Realizo manobras operacionais, relato anomalias e faço inspeções de ronda regularmente. Também opero a dosagem de produtos químicos para tratamento e controle de parâmetros, bombas de recalque para distribuição, faço a lavagem de filtros de areia com controle dos parâmetros exigidos pelo Inea e das metas operacionais, e opero geradores de energia elétrica e sistemas de emergência.

Foi observando de perto os desafios reais da rotina operacional — como a dificuldade de conciliar a operação da planta com o registro adequado de dados durante a passagem de turno — que nasceu, anos depois, a ideia por trás do meu projeto Flow State Shift, uma solução de UX pensada justamente para quem vive esse tipo de rotina industrial.

---

## Uma nova formação, um novo caminho (2024 – 2026)

Enquanto seguia atuando na CSN, decidi investir intensamente em uma nova direção de carreira: a Tecnologia da Informação. Entre 2024 e 2026, mergulhei no programa Oracle Next Education (ONE), em parceria com a Alura, cursando centenas de horas em Cloud Computing (Oracle Cloud Infrastructure), bancos de dados com SQL e MySQL, Python aplicado à análise de dados e ETL, Machine Learning, programação web com JavaScript, HTML e CSS, DevOps e Linux, metodologias ágeis, e Inteligência Artificial Generativa — incluindo Engenharia de Prompt, arquitetura RAG e Agentes de IA com LangChain.

Paralelamente, iniciei a Tecnologia em Segurança da Informação, curso que concluo neste mês de julho de 2026, consolidando de forma acadêmica um interesse que já vinha sendo reforçado por formações complementares como Gestor de Políticas de Segurança da Informação, Assistente Técnico de Segurança da Informação e Pentest Básico.

Foi nesse período que comecei a colocar a mão na massa em projetos autorais: desde aplicações front-end como jogos interativos e ferramentas de criptografia, até projetos mais robustos de dados e IA, como o Dashboard do Mercado Siderúrgico Brasileiro — que uniu meu conhecimento técnico em análise de dados ao meu conhecimento prático do setor onde trabalho — e o Kaida AI Risk Detector, um MVP acadêmico de prevenção de vazamento de dados em prompts de IA, alinhado a LGPD e governança de IA.

Também participei do desafio de Data Science Telecom X2 do próprio programa ONE/Alura, construindo modelos preditivos de evasão de clientes (churn), e desenvolvi o Módulo H4 do projeto Repertor.IA, como Trabalho de Conclusão de Curso na Oficina Ágil - Academia MCIO Brasil, uma plataforma voltada a mulheres 40+ em transição de carreira para tecnologia — um tema que dialoga diretamente com a minha própria trajetória.

---

## O momento atual

Hoje, sigo atuando como Operadora de Produção II na CSN, unindo mais de dez anos de experiência operacional e administrativa sólida a uma formação técnica recente e abrangente em Tecnologia da Informação, Segurança da Informação, Cloud e Análise de Dados. Meu objetivo agora é migrar minha atuação profissional para as áreas de TI, Suporte Técnico/Cloud, Análise de Dados ou Administração, aplicando essa combinação pouco comum entre vivência industrial de longo prazo e capacitação atualizada em tecnologia.

O próprio PortfolioAI — o assistente de IA que estou desenvolvendo para contar essa história de forma conversacional — é um reflexo direto desse momento: um projeto que aplica na prática os conhecimentos de RAG, LangChain e IA Generativa que venho construindo, ao mesmo tempo em que serve como vitrine de tudo o que já construí ao longo da carreira.

---

## Notas de manutenção (uso interno)

- Este documento deve ser atualizado sempre que uma nova experiência profissional, mudança de cargo ou marco relevante ocorrer.
- Manter o tom narrativo e em primeira pessoa, evitando linguagem excessivamente promocional ou afirmações não verificáveis pelo currículo oficial.
- Ao adicionar novos projetos ou formações no futuro, buscar conectar com o momento da trajetória em que fizeram sentido cronologicamente, mantendo a coerência da história.
