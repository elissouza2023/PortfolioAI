# Formação e Certificações — Elisângela de Souza

> Documento de referência para a base de conhecimento do PortfolioAI. Contém a formação acadêmica e todas as certificações/cursos complementares, com descrição de conteúdo e carga horária, para fundamentar respostas conversacionais sobre qualificação técnica.

---

## Formação Acadêmica

### Bacharelado em Administração de Empresas
Concluído. É minha formação de base, que sustenta minha atuação em rotinas administrativas, gestão de equipes e controle de processos ao longo de toda a minha trajetória profissional.

### Pós-Graduação em Engenharia Metalúrgica
Concluída. Essa formação dialoga diretamente com minha atuação na indústria siderúrgica, onde trabalho há mais de uma década na CSN, e reforça meu entendimento técnico sobre processos industriais do setor.

### Pós-Graduação em Engenharia de Equipamentos
Incompleta. Iniciei essa pós-graduação como aprofundamento técnico complementar à minha atuação na área industrial.

### Técnico em Administração de Empresas
Concluído, na modalidade técnica, anterior à graduação em Administração.

### Técnico em Contabilidade
Curso complementar concluído, que ampliou minha base de conhecimentos administrativos e financeiros.

### Tecnologia em Segurança da Informação
Concluída neste mês (julho de 2026). Esta é minha formação mais recente e estratégica, marcando minha transição de foco para a área de Tecnologia da Informação, com ênfase em segurança digital, proteção de dados e governança de TI.

---

## Formação Complementar — Programa Oracle Next Education (ONE) / Alura (2024 a 2026)

O programa Oracle Next Education, em parceria com a Alura, foi minha principal via de capacitação intensiva em Tecnologia da Informação nos últimos anos. Reúne trilhas de nuvem, banco de dados, programação, ciência de dados e inteligência artificial, totalizando centenas de horas de formação prática.

### Nuvem & Infraestrutura (Oracle & DevOps)

**OCI Foundations Associate & Cloud — 48 horas**
Formação voltada à implantação de aplicações na nuvem Oracle Cloud Infrastructure (OCI), cobrindo banco de dados OCI, Infraestrutura como Código (IaC) e monitoramento de ambientes em nuvem. Essa trilha também me credenciou para a Certificação Oracle Cloud Infrastructure 2025 (código 170-1085-25).

**DevOps & Linux — 14 horas**
Curso focado em comandos e scripts via linha de comando (CLI) no Linux, além de conceitos de tráfego seguro em comunicações web — uma base prática para rotinas de operação e automação de infraestrutura.

**Oracle Autonomous Database & APEX — 6 horas**
Formação sobre o Autonomous Database da Oracle e desenvolvimento low-code com apoio de IA na plataforma Oracle APEX, permitindo criar aplicações de forma ágil sobre bancos de dados gerenciados.

### Banco de Dados, Programação & Dados

**Consultas SQL com MySQL Server — 47 horas**
Curso prático de manipulação de dados em bancos relacionais, incluindo criação de procedures, funções e consultas SQL voltadas à análise de dados.

**Análise de Dados & ETL com Python — 111 horas**
Uma das formações mais extensas do programa. Cobriu modelagem de dados nos níveis conceitual, lógico e físico, estruturas de dados em Python, uso da biblioteca NumPy e transformação de dados (ETL) com Pandas.

**Estatística & Machine Learning — 61 horas**
Curso sobre regressão linear, algoritmos de classificação, validação de modelos e análise estatística aplicada, utilizando Python como ferramenta principal. Essa formação foi aplicada na prática no projeto Jupiter Telecom X2, de previsão de evasão de clientes (churn).

**Iniciante em Programação — 70 horas**
Formação introdutória com lógica de programação usando JavaScript, HTML5 e CSS3 (incluindo Flexbox e responsividade), além de versionamento de código com Git e GitHub. Essa base foi aplicada em diversos dos meus projetos front-end, como os jogos interativos e aplicações web que desenvolvi.

### Inteligência Artificial & Agilidade

**IA Generativa & AI for Tech — 94 horas**
Formação avançada em Engenharia de Prompt, arquitetura RAG (Retrieval-Augmented Generation), construção de Agentes de IA com LangChain, e otimização de produtividade com ferramentas como o ChatGPT. É justamente esse conhecimento que estou aplicando no desenvolvimento do PortfolioAI, meu assistente de portfólio baseado em IA.

**Metodologias Ágeis & Carreira — 82 horas**
Curso sobre gestão ágil com Scrum e Kanban, além de temas de empreendedorismo e desenvolvimento pessoal para a carreira em tecnologia. Também apliquei metodologia ágil, com priorização MoSCoW, no desenvolvimento do projeto Repertor.IA.

**Certificado geral do programa**
Todo o percurso formativo no Oracle Next Education/Alura está consolidado em um certificado geral, disponível para visualização mediante link informado no meu currículo de TI.

---

## Certificações e Formações em Segurança da Informação

**Certificação Oracle Cloud Infrastructure 2025 (170-1085-25)**
Certificação oficial Oracle obtida através da trilha de nuvem do programa ONE/Alura.

**Gestor de Políticas de Segurança da Informação**
Formação voltada à definição e gestão de políticas corporativas de segurança da informação.

**Assistente Técnico de Segurança da Informação**
Formação técnica de apoio a rotinas e processos de segurança da informação em ambientes corporativos.

**Pentest Básico**
Formação introdutória em testes de penetração (pentest), com foco em identificação de vulnerabilidades básicas de segurança.

---

## Outras Certificações e Treinamentos Técnicos

**CCNA Routing and Switching (Cisco)**
Treinamento na certificação Cisco voltado a roteamento e comutação de redes.

**Ferramentas de Design**
Conhecimento em Figma, Canva, Photoshop, CorelDraw e Padlet, aplicados tanto em projetos de design/UX quanto na produção de materiais e apresentações ao longo da carreira administrativa.

---

## Treinamentos em Segurança do Trabalho e Emergência

Ao longo da atuação na indústria siderúrgica (CSN), obtive as seguintes formações e certificações de segurança operacional:

- **Brigadista**
- **Socorrista**
- **PRE de Gás Cloro (combatente)** — Plano de Resposta a Emergências envolvendo gás cloro
- **PRE combate a efluentes no emissário (RPS)**
- **NR 33 (Entrante)** — trabalho em espaços confinados
- **NR 12** — segurança em máquinas e equipamentos
- **NR 35** — trabalho em altura
- **NR 4** — serviços especializados em segurança e medicina do trabalho
- **Eletricista Residencial, Predial e Industrial e CLP** — formação em instalações elétricas e controladores lógicos programáveis

---

## Idiomas

**Inglês** — nível básico (A2).
**Espanhol** — nível básico.

---

## Notas de manutenção (uso interno)

- Atualizar a data exata de conclusão da Tecnologia em Segurança da Informação assim que o certificado for emitido oficialmente.
- Ao concluir novos cursos ou certificações, seguir o mesmo padrão: nome da formação, carga horária (quando aplicável), conteúdo abordado e, se possível, conexão com um projeto prático ou experiência profissional real.
- Este documento deve ser mantido sincronizado com o arquivo de Competências e com o FAQ, evitando divergências de carga horária ou nomenclatura entre os documentos da base de conhecimento.
